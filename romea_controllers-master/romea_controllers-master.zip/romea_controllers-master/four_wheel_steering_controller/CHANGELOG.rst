^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package four_wheel_steering_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.2 (2017-02-02)
------------------
* Add test depend
* Contributors: Vincent Rousseau

0.2.1 (2017-02-01)
------------------
* [4ws] Add crab travel test
* [4ws] Update test
* [4ws] Add test on non symmetric steering
* [4ws] Revert to use only rear speed for odom
* [4ws] Use front and rear speed for odometry
* Update computation of virtual steering
* [4ws] Remove debug
* [4ws] Update command with 4ws msg
* Update test for four_wheel_steering_controller
* Contributors: Vincent Rousseau

0.2.0 (2017-01-19)
------------------
* [4ws] Only enable twist cmd
* [4ws] Fix velocity cmd inversion
* [4ws] Integrate position using x and y velocity
* [4ws] use linear x and y for speed
* [4ws] update odometry formula
* Contributors: Vincent Rousseau

0.1.2 (2016-09-05)
------------------

0.1.1 (2016-08-31)
------------------
