^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package four_wheel_steering_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.2 (2017-02-02)
------------------

0.2.1 (2017-02-01)
------------------

0.2.0 (2017-01-19)
------------------
* Update CMakelists and package format
* [four_wheel_steering_msgs] First version from ackermann_msgs refs #2
* Contributors: Vincent Rousseau

0.1.2 (2016-09-05)
------------------

0.1.1 (2016-08-31)
------------------
