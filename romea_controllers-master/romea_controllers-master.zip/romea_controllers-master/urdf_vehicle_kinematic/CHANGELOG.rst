^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package urdf_vehicle_kinematic
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.2 (2017-02-02)
------------------
* [urdf_kinematic] Install header file
* Contributors: Vincent Rousseau

0.2.1 (2017-02-01)
------------------
* Update computation of virtual steering
* Contributors: Vincent Rousseau

0.2.0 (2017-01-19)
------------------
* Create the package urdf_vehicle_kinematic
* Contributors: Vincent Rousseau

0.1.2 (2016-09-05)
------------------

0.1.1 (2016-08-31)
------------------
